﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp12
{
    class Triangle : ColoredFigure
    {
        public Triangle(string color, double size)
            : base(color, size)
        {

        }

        public override double GetArea()
        {

            return Math.Round((Math.Pow(size, 2) * Math.Sqrt(3)) / 2, 2);
        }
    }
}
