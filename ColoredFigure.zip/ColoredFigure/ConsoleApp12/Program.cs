﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp12
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string[] input = Console.ReadLine().Split();
                switch (input[0])
                {
                    case "Triangle":
                        Triangle triang = new Triangle(input[1], double.Parse(input[2]));
                        triang.GetName();
                        triang.Show();
                        Console.WriteLine("Area: " + triang.GetArea());
                        break;

                    case "Square":
                        Square squr = new Square(input[1], double.Parse(input[2]));
                        squr.GetName();
                        squr.Show();
                        Console.WriteLine("Area: " + squr.GetArea());
                        break;

                    case "Circle":
                        Circle circle = new Circle(input[1], double.Parse(input[2]));
                        circle.GetName();
                        circle.Show();
                        Console.WriteLine("Area: " + circle.GetArea());
                        break;
                    default:
                        Console.WriteLine("What is " + input[0] + "?");
                        break;
                }
            }
        }
    }
}
